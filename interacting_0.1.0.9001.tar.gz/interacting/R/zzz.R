
    
        
  .onLoad <- function(libname, pkgname) {
  
     
  
    } #End of onLoad


#8. Attaching 
    
    .onAttach <- function(libname, pkgname) {
      
        
      #While developing:
         packageStartupMessage ("#######################################################\n",
                                "interacting v.0.1.0  DEV version: 2024 04 03 [4.18 BCN]")

      
      
  } #End on attach
    
    
      
 