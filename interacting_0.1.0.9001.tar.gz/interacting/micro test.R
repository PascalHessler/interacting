library('groundhog')
pkgs=c('mgcv','devtools','this.path')
date='2024-02-01'
groundhog.library(pkgs,date)


  pkg_path <- "c:/git/interacting/r"
  #pkg_path <- "/Users/andres/Documents/[2] projects/[7] interacting/interacting/R" #in Andres's computer
  
  
#INSTALL
  devtools::document(pkg_path)
  #devtools::build(pkg_path,path=this.dir())
  devtools::install(pkg_path, dependencies = FALSE, build = TRUE)
  
  
  install.packages(file.path(dirname(pkg_path),'interacting'))
  
  
  library('interacting')

  
  n=5005
  x1=rnorm(n)
  z1=rnorm(n)
  y1.raw=x1*z1+pmin(z1,0)
  e=rnorm(n,sd(y1.raw))
  y1=y1.raw+e
  
  
  
